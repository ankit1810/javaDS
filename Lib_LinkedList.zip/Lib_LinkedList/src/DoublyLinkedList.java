public class DoublyLinkedList {
    Node head;
    void doubly_insertAtLast(int data)
    {
        Node node=new Node();
        node.data=data;
        node.next=null;
        if(head==null)
        {
            head=node;
            head.prev=null;
        }
        else
        {
            Node temp=head;
            while(temp.next!=null){
                temp=temp.next;
            }
            temp.next=node;
            node.prev=temp;
        }

    }
    void doubly_insertAt(int data,int after)
    {
        Node node=new Node();
        Node temp=head,previous=null;
        node.data=data;
        node.next=node.prev=null;
        while(temp.data!=after)
        {
            temp=temp.next;
        }
        if(temp.data==after)
        {
           node.next=temp.next;
           node.prev=temp;
           temp.next=node;
           if(node.next!=null)
               node.next.prev=node;

        }
        else
            System.out.println("ELEMENT NOT PRESENT IN THE LIST");

    }
    void doubly_delete(int data)
    {
        Node temp=head,previous=null;
        if(temp==null)
        {
            System.out.println("EMPTY DOUBLE ENDED QUEUE");
        }
        else if (temp.data==data)
        {

            head=head.next;
            head.prev=null;
        }
        else
        {
            while(temp!=null && temp.data!=data)
            {
                previous=head;
                temp=temp.next;
            }
            if(temp==null)
                System.out.println("ELEMENT NOT PRESENT");
            else
            {
                previous.next=temp.next;
                temp.next.prev=temp.prev;
            }
        }
    }
    void doubly_show()
    {
        Node temp=head;
        while(temp.next!=null)
        {
            System.out.println(temp.data);
            temp=temp.next;
        }
        System.out.println(temp.data);
    }
}
