public class QueueLib {
    Node front;
    Node rear;
    void Enqueue(int data)
    {
        Node node = new Node();
        node.data=data;
        if(front==null){
        front=node;
        rear=node;
        node.next=null;
        }
        else
        {
            rear.next=node;
            rear=node;
        }
    }
    void Dequeue()
    {
        Node temp=front;
        if(temp==null)
        {
            System.out.println("QUEUE EMPTY");
        }
        else
        {
            System.out.println("ELEMENT TO BE DELETED IS "+temp.data);
            front=temp.next;

        }
    }
    void show()
    {
        Node temp=front;
        while(temp.next!=null)
        {
            System.out.println(temp.data);
            temp=temp.next;
        }
        System.out.println(temp.data);
    }
}
