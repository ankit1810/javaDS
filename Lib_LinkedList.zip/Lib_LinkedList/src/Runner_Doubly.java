public class Runner_Doubly
{
    public static void main(String[] args) {
        DoublyLinkedList obj=new DoublyLinkedList();
        obj.doubly_insertAtLast(25);
        obj.doubly_insertAtLast(20);
        obj.doubly_insertAtLast(15);
        obj.doubly_delete(25);
        obj.doubly_insertAt(30,20);
        obj.doubly_show();
    }
}
