public class StackLib {
    Node top;
    void push(int data)
    {
        Node node=new Node();
        node.data=data;
        if(top==null)
        {
                node.next=null;
                top=node;
        }
        else
        {
            node.next=top;
            top=node;

        }
    }
    void pop()
    {
        Node temp=top;
        if(top==null)
            System.out.println("STACK EMPTY");
        else
        {
            System.out.println("THE TOP ELEMENT "+top.data+" IS DELETED");
            top=top.next;
        }
    }
    void stack_show()
    {
        Node temp=top;
        while(temp.next!=null)
        {
            System.out.println(temp.data);
            temp=temp.next;
        }
        System.out.println(temp.data);
    }
}
