import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

public class LinkedList {
    public Node head;
    void insert(int data)
    {
        Node node=new Node();
        node.data=data;
        node.next=null;
        if(head==null)
        {
            head=node;
        }
        else
        {
            Node temp=head;
            while(temp.next!=null)
            {
                temp=temp.next;
            }
            temp.next=node;
        }
    }
    void insertAt(int data,int after)
    {
        Node node = new Node();
        node.data=data;
        node.next=null;
        Node temp=head;
        while(temp.data!=after)
        {
            temp=temp.next;
        }
        node.next=temp.next;
        temp.next=node;

    }
    void delete(int data)
    {
        Node temp=head,prev=null;
        if(temp==null)
            System.out.println("LINKED LIST IS EMPTY");
        else if(temp.data==data)
        {
            head=head.next;
            System.out.println("SUCCESSFULLY DELETED head");
        }
        else
        {
            while (temp!=null && temp.data!=data)
            {
                prev=temp;
                temp=temp.next;
            }
            if(temp==null)
                System.out.print("ELEMENT NOT PRESENT");
            else
            {
                System.out.println("SUCCESSFUL DELETED");
                prev.next=temp.next;
            }
        }
    }
    void show()
    {
        Node temp=head;
        while(temp.next!=null)
        {
            System.out.print(temp.data+"---->");
            temp=temp.next;
        }

        System.out.print(temp.data);
    }
    void reverse(){
        printReverse(head);
    }

    void printReverse(Node head) {
        if(head==null)
            return;
        printReverse(head.next);
        System.out.println(head.data);
    }
}
