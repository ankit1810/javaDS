import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.Buffer;

public class Runner {
    public static void main(String[] args) throws IOException {
        LinkedList obj=new LinkedList();
        BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        int data,after;
        while(1==1)
        {
            System.out.println("\n");
            System.out.println("1 -----> insert at starting");
            System.out.println("2 -----> insert after something");
            System.out.println("3 -----> delete data");
            System.out.println("4 -----> show");
            System.out.println("5 -----> exit");
            int n=Integer.parseInt(br.readLine());
            switch (n){
                case 1:
                    System.out.println("enter the data");
                    data=Integer.parseInt(br.readLine());
                    obj.insert(data);
                    break;
                case 2:
                    System.out.println("Enter data and after ");
                    data=Integer.parseInt(br.readLine());
                    after=Integer.parseInt(br.readLine());
                    obj.insertAt(data,after);
                    break;
                case 3:
                    System.out.println("enter the data to be deleted");
                    data=Integer.parseInt(br.readLine());
                    obj.delete(data);
                    break;
                case 4:
                    obj.show();
                    break;
                case 5:
                    obj.reverse();
                case 6:
                    System.exit(0);

            }
        }
    }
}
