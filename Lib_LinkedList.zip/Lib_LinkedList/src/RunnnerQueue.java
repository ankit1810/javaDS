import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class RunnnerQueue {
    public static void main(String[] args)throws IOException {
        QueueLib obj=new QueueLib();
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        while(true)
        {
            int num;
            System.out.println("WELCOME TO QUEUE");
            System.out.println("1----------> ENTER");
            System.out.println("2----------> DELETE");
            System.out.println("3----------> Show");
            System.out.println("4----------> Exit");
            int choice=Integer.parseInt(br.readLine());
            switch(choice)
            {
                case 1:
                    System.out.println("Enter the number to be pushed");
                    num=Integer.parseInt(br.readLine());
                    obj.Enqueue(num);
                    System.out.print('\u000C');
                    break;
                case 2:
                    System.out.println("Top Element poped");
                    obj.Dequeue();
                    System.out.print('\u000C');
                    break;
                case 3:
                    System.out.println("THE ELEMENTS ARE ");
                    obj.show();break;
                case 4:
                    System.exit(0);

            }
        }
    }
}
